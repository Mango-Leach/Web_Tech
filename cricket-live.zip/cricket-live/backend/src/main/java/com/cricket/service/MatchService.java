package com.cricket.service;

import com.cricket.model.*;
import jakarta.annotation.PostConstruct;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

@Service
public class MatchService {
    private static final String[] FIRST = {"Aarav","Rohan","Vikram","Karan","Imran","Dev","Arjun","Nikhil","Sameer","Tushar","Yash","Harsh","Zaid","Manav","Omkar","Rahul"};
    private static final String[] LAST = {"Patil","Sharma","Khan","Iyer","Verma","Nair","Joshi","Reddy","Singh","Kulkarni","Das","Mehta","Gupta","Bhat","Shinde","Rao"};
    private static final String[] ROLES = {"Opener","Opener","Batter","Batter","All-rounder","Wicketkeeper","All-rounder","Bowler","Bowler","Bowler","Bowler"};

    private final Map<String, Match> matches = new LinkedHashMap<>();
    private final List<SseEmitter> emitters = new CopyOnWriteArrayList<>();
    private final Random rnd = new Random();
    private int seq = 0;

    @PostConstruct
    void seed() {
        create("Pune Panthers", "Mumbai Mariners", "MCA Stadium, Pune");
        create("Delhi Dynamos", "Chennai Chargers", "Arun Jaitley Stadium, Delhi");
    }

    public synchronized Match create(String a, String b, String venue) {
        Match m = new Match();
        m.id = "m" + (++seq); m.teamA = a; m.teamB = b; m.venue = venue;
        m.battingTeam = a; m.bowlingTeam = b;
        m.squads.put(a, squad()); m.squads.put(b, squad());
        m.commentary.add(0, "Toss done. " + a + " will bat first.");
        matches.put(m.id, m);
        return m;
    }

    private List<Player> squad() {
        List<String> used = new ArrayList<>(); List<Player> list = new ArrayList<>();
        for (String role : ROLES) {
            String n; do { n = FIRST[rnd.nextInt(FIRST.length)] + " " + LAST[rnd.nextInt(LAST.length)]; } while (used.contains(n));
            used.add(n); list.add(new Player(n, role));
        }
        return list;
    }

    public synchronized List<Match> all() { return new ArrayList<>(matches.values()); }
    public synchronized Match get(String id) { return matches.get(id); }

    @Scheduled(fixedRate = 1500)
    public synchronized void tick() {
        for (Match m : matches.values()) if (m.status.equals("LIVE")) { bowl(m, null); broadcast(m); }
    }

    /** Applies one delivery. outcome: 0,1,2,3,4,6,W,Wd (null = random). */
    public synchronized Match score(String id, String outcome) {
        Match m = matches.get(id);
        if (m == null || !m.status.equals("LIVE")) return m;
        bowl(m, outcome); broadcast(m); return m;
    }

    private String pick() {
        int x = rnd.nextInt(100);
        if (x < 28) return "0"; if (x < 56) return "1"; if (x < 64) return "2"; if (x < 65) return "3";
        if (x < 77) return "4"; if (x < 83) return "6"; if (x < 89) return "W"; if (x < 93) return "Wd";
        return "1";
    }

    private void bowl(Match m, String outcome) {
        if (outcome == null) outcome = pick();
        List<Player> bat = m.squads.get(m.battingTeam), bowl = m.squads.get(m.bowlingTeam);
        Player s = bat.get(m.striker), b = bowl.get(6 + m.bowlerIdx % 5);
        boolean legal = true; String text;
        switch (outcome) {
            case "Wd" -> { m.runs++; b.runsConceded++; legal = false; text = "Wide"; }
            case "W" -> {
                s.balls++; s.out = true; s.dismissal = "b " + b.name; b.wickets++; m.wickets++;
                text = "OUT! " + s.name + " is bowled by " + b.name;
                if (m.wickets < 10) m.striker = m.nextBatter++;
            }
            default -> {
                int r = Integer.parseInt(outcome);
                s.runs += r; s.balls++; m.runs += r; b.runsConceded += r;
                if (r == 4) s.fours++; if (r == 6) s.sixes++;
                text = r == 0 ? "dot ball" : r == 4 ? "FOUR!" : r == 6 ? "SIX!" : r + (r == 1 ? " run" : " runs");
                if (r % 2 == 1) swap(m);
            }
        }
        if (legal) {
            m.balls++; b.ballsBowled++;
            if (m.balls % 6 == 0) { swap(m); m.bowlerIdx++; }
        }
        m.recent.add(outcome);
        String ov = (m.balls / 6) + "." + (m.balls % 6);
        m.commentary.add(0, ov + "  " + b.name + " to " + s.name + ", " + text);
        if (m.commentary.size() > 40) m.commentary.remove(m.commentary.size() - 1);
        if (legal && m.balls % 6 == 0) m.recent.clear();

        boolean over = m.wickets >= 10 || m.balls >= m.maxOvers * 6 || (m.innings == 2 && m.runs >= m.target);
        if (over) endInnings(m);
    }

    private void swap(Match m) { int t = m.striker; m.striker = m.nonStriker; m.nonStriker = t; }

    private void endInnings(Match m) {
        if (m.innings == 1) {
            m.firstInningsRuns = m.runs; m.firstInningsWickets = m.wickets; m.firstInningsBalls = m.balls;
            m.target = m.runs + 1;
            m.commentary.add(0, "Innings break. " + m.bowlingTeam + " need " + m.target + " to win.");
            String t = m.battingTeam; m.battingTeam = m.bowlingTeam; m.bowlingTeam = t;
            m.innings = 2; m.runs = 0; m.wickets = 0; m.balls = 0;
            m.striker = 0; m.nonStriker = 1; m.nextBatter = 2; m.bowlerIdx = 0; m.recent.clear();
        } else {
            m.status = "COMPLETED";
            if (m.runs >= m.target) m.result = m.battingTeam + " won by " + (10 - m.wickets) + " wickets";
            else if (m.runs == m.target - 1) m.result = "Match tied";
            else m.result = m.bowlingTeam + " won by " + (m.target - 1 - m.runs) + " runs";
            m.commentary.add(0, m.result);
        }
    }

    public synchronized Map<String, Object> summary(String id) {
        Match m = matches.get(id); if (m == null) return null;
        Player top = null, best = null; String topTeam = "", bestTeam = "";
        int fours = 0, sixes = 0;
        for (var e : m.squads.entrySet()) for (Player p : e.getValue()) {
            fours += p.fours; sixes += p.sixes;
            if (top == null || p.runs > top.runs) { top = p; topTeam = e.getKey(); }
            if (p.ballsBowled > 0 && (best == null || p.wickets > best.wickets
                    || (p.wickets == best.wickets && p.runsConceded < best.runsConceded))) { best = p; bestTeam = e.getKey(); }
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("status", m.status); out.put("result", m.result);
        out.put("topScorer", top == null || top.runs == 0 ? null : Map.of("name", top.name, "team", topTeam, "runs", top.runs, "balls", top.balls));
        out.put("bestBowler", best == null ? null : Map.of("name", best.name, "team", bestTeam, "wickets", best.wickets, "runs", best.runsConceded));
        out.put("totalFours", fours); out.put("totalSixes", sixes);
        out.put("runRate", m.balls == 0 ? 0 : Math.round(m.runs * 600.0 / m.balls) / 100.0);
        if (m.innings == 2 && m.status.equals("LIVE")) {
            int left = m.maxOvers * 6 - m.balls;
            out.put("required", m.target - m.runs);
            out.put("requiredRate", left == 0 ? 0 : Math.round((m.target - m.runs) * 600.0 / left) / 100.0);
        }
        return out;
    }

    public SseEmitter subscribe() {
        SseEmitter em = new SseEmitter(0L);
        emitters.add(em);
        em.onCompletion(() -> emitters.remove(em)); em.onTimeout(() -> emitters.remove(em)); em.onError(e -> emitters.remove(em));
        return em;
    }

    private void broadcast(Match m) {
        for (SseEmitter em : emitters) {
            try { em.send(SseEmitter.event().name("match").data(m)); }
            catch (Exception e) { emitters.remove(em); }
        }
    }
}
