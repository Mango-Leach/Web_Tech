package com.cricket.model;

/** One player: batting and bowling stats live on the same object. */
public class Player {
    public String name, role, dismissal = "";
    public int runs, balls, fours, sixes;              // batting
    public boolean out;
    public int ballsBowled, runsConceded, wickets;     // bowling
    public Player(String name, String role) { this.name = name; this.role = role; }
}
