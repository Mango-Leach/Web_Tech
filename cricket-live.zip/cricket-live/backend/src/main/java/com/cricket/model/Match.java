package com.cricket.model;

import java.util.*;

public class Match {
    public String id, teamA, teamB, venue, status = "LIVE", battingTeam, bowlingTeam, result = "";
    public int innings = 1, runs, wickets, balls, maxOvers = 20, target;
    public int striker = 0, nonStriker = 1, nextBatter = 2, bowlerIdx = 0;
    public int firstInningsRuns, firstInningsWickets, firstInningsBalls;
    public Map<String, List<Player>> squads = new LinkedHashMap<>();
    public List<String> recent = new ArrayList<>();      // balls of the current over
    public List<String> commentary = new ArrayList<>();  // newest first
}
