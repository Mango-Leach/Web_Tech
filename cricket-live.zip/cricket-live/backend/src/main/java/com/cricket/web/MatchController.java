package com.cricket.web;

import com.cricket.model.*;
import com.cricket.service.MatchService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class MatchController {
    private final MatchService svc;
    public MatchController(MatchService svc) { this.svc = svc; }

    private Match find(String id) {
        Match m = svc.get(id);
        if (m == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Match not found");
        return m;
    }

    @GetMapping("/matches") public List<Match> matches() { return svc.all(); }
    @GetMapping("/matches/{id}") public Match match(@PathVariable String id) { return find(id); }
    @GetMapping("/matches/{id}/players") public Map<String, List<Player>> players(@PathVariable String id) { return find(id).squads; }
    @GetMapping("/matches/{id}/summary") public Map<String, Object> summary(@PathVariable String id) { find(id); return svc.summary(id); }

    @PostMapping("/matches")
    public Match create(@RequestBody Map<String, String> b) {
        return svc.create(b.getOrDefault("teamA", "Team A"), b.getOrDefault("teamB", "Team B"), b.getOrDefault("venue", "Local Ground"));
    }

    /** Manual score update. Body: {"outcome":"4"} where outcome is 0,1,2,3,4,6,W or Wd. */
    @PostMapping("/matches/{id}/score")
    public Match score(@PathVariable String id, @RequestBody Map<String, String> b) {
        find(id);
        String o = b.getOrDefault("outcome", "");
        if (!List.of("0","1","2","3","4","6","W","Wd").contains(o))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "outcome must be one of 0,1,2,3,4,6,W,Wd");
        return svc.score(id, o);
    }

    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream() { return svc.subscribe(); }
}
