import { useEffect, useState } from 'react'

const api = (p, opt) => fetch('/api' + p, opt).then(r => r.json())
const ov = b => `${Math.floor(b / 6)}.${b % 6}`
const sr = (r, b) => (b ? ((r * 100) / b).toFixed(1) : '-')
const eco = (r, b) => (b ? ((r * 6) / b).toFixed(1) : '-')
const chip = o => (o === 'W' ? 'w' : o === '4' ? 'f' : o === '6' ? 's' : o === 'Wd' ? 'wd' : '')

export default function App() {
  const [matches, setMatches] = useState([])
  const [sel, setSel] = useState(null)
  const [tab, setTab] = useState('scorecard')
  const [summary, setSummary] = useState(null)
  const [online, setOnline] = useState(false)

  useEffect(() => {
    api('/matches').then(d => { setMatches(d); setSel(s => s || d[0]?.id) })
    const es = new EventSource('/api/stream')
    es.onopen = () => setOnline(true)
    es.onerror = () => setOnline(false)
    es.addEventListener('match', e => {
      const m = JSON.parse(e.data)
      setMatches(ms => (ms.some(x => x.id === m.id) ? ms.map(x => (x.id === m.id ? m : x)) : [...ms, m]))
    })
    return () => es.close()
  }, [])

  const m = matches.find(x => x.id === sel)
  useEffect(() => { if (tab === 'summary' && sel) api(`/matches/${sel}/summary`).then(setSummary) }, [tab, sel, m?.balls, m?.status])

  const post = (path, body) => api(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
  const newMatch = async () => {
    const teamA = prompt('Team A', 'Bengaluru Bulls'); const teamB = prompt('Team B', 'Kolkata Knights')
    if (teamA && teamB) { const nm = await post('/matches', { teamA, teamB, venue: 'Local Ground' }); setMatches(ms => [...ms, nm]); setSel(nm.id) }
  }

  return (
    <div className="app">
      <aside>
        <h1>Cricket Live <span className={online ? 'dot on' : 'dot'} title={online ? 'Connected' : 'Reconnecting'} /></h1>
        {matches.map(x => (
          <button key={x.id} className={'mcard' + (x.id === sel ? ' active' : '')} onClick={() => setSel(x.id)}>
            <b>{x.teamA} v {x.teamB}</b>
            <span>{x.status === 'COMPLETED' ? x.result : `${x.battingTeam} ${x.runs}/${x.wickets} (${ov(x.balls)})`}</span>
          </button>
        ))}
        <button className="ghost" onClick={newMatch}>Start new match</button>
      </aside>

      {m ? (
        <main>
          <header className="hero">
            <p>{m.venue} · Innings {m.innings}{m.status === 'LIVE' ? '' : ' · Completed'}</p>
            <h2>{m.battingTeam}</h2>
            <div className="big">{m.runs}<small>/{m.wickets}</small> <em>{ov(m.balls)} / {m.maxOvers} ov</em></div>
            {m.innings === 2 && m.status === 'LIVE' && <p className="chase">{m.bowlingTeam} scored {m.firstInningsRuns}. Need {m.target - m.runs} from {m.maxOvers * 6 - m.balls} balls.</p>}
            {m.status === 'COMPLETED' && <p className="chase">{m.result}</p>}
            <div className="over">{m.recent.map((o, i) => <span key={i} className={'ball ' + chip(o)}>{o}</span>)}</div>
          </header>

          {m.status === 'LIVE' && (
            <div className="keys" aria-label="Update score">
              {['0', '1', '2', '3', '4', '6', 'W', 'Wd'].map(o => (
                <button key={o} className={'ball ' + chip(o)} onClick={() => post(`/matches/${m.id}/score`, { outcome: o })}>{o}</button>
              ))}
            </div>
          )}

          <nav className="tabs">
            {['scorecard', 'commentary', 'summary'].map(t => <button key={t} className={t === tab ? 'on' : ''} onClick={() => setTab(t)}>{t[0].toUpperCase() + t.slice(1)}</button>)}
          </nav>

          {tab === 'scorecard' && Object.entries(m.squads).map(([team, ps]) => {
            const batting = ps.map((p, i) => ({ ...p, i })).filter(p => p.balls > 0 || p.out || (team === m.battingTeam && p.i < m.nextBatter && m.status === 'LIVE'))
            const bowling = ps.filter(p => p.ballsBowled > 0)
            const opp = Object.keys(m.squads).find(t => t !== team)
            return (
              <section key={team}>
                <h3>{team} batting</h3>
                <div className="scroll"><table><thead><tr><th>Batter</th><th></th><th>R</th><th>B</th><th>4s</th><th>6s</th><th>SR</th></tr></thead><tbody>
                  {batting.map(p => {
                    const atCrease = team === m.battingTeam && m.status === 'LIVE' && !p.out && (p.i === m.striker || p.i === m.nonStriker)
                    return <tr key={p.name} className={atCrease ? 'now' : ''}><td>{p.name}{p.i === m.striker && atCrease ? ' *' : ''}</td><td className="mut">{p.out ? p.dismissal : atCrease ? 'batting' : 'not out'}</td><td><b>{p.runs}</b></td><td>{p.balls}</td><td>{p.fours}</td><td>{p.sixes}</td><td>{sr(p.runs, p.balls)}</td></tr>
                  })}
                </tbody></table></div>
                {bowling.length > 0 && <>
                  <h3>{opp} bowling</h3>
                  <div className="scroll"><table><thead><tr><th>Bowler</th><th>O</th><th>R</th><th>W</th><th>Eco</th></tr></thead><tbody>
                    {bowling.map(p => <tr key={p.name}><td>{p.name}</td><td>{ov(p.ballsBowled)}</td><td>{p.runsConceded}</td><td><b>{p.wickets}</b></td><td>{eco(p.runsConceded, p.ballsBowled)}</td></tr>)}
                  </tbody></table></div></>}
              </section>
            )
          })}

          {tab === 'commentary' && <ul className="comm">{m.commentary.map((c, i) => <li key={i}>{c}</li>)}</ul>}

          {tab === 'summary' && summary && (
            <section className="sum">
              {summary.result && <h3>{summary.result}</h3>}
              <dl>
                <dt>Top scorer</dt><dd>{summary.topScorer ? `${summary.topScorer.name} (${summary.topScorer.team}) ${summary.topScorer.runs} off ${summary.topScorer.balls}` : '-'}</dd>
                <dt>Best bowler</dt><dd>{summary.bestBowler ? `${summary.bestBowler.name} (${summary.bestBowler.team}) ${summary.bestBowler.wickets}/${summary.bestBowler.runs}` : '-'}</dd>
                <dt>Current run rate</dt><dd>{summary.runRate}</dd>
                {summary.requiredRate !== undefined && <><dt>Required rate</dt><dd>{summary.requiredRate}</dd></>}
                <dt>Boundaries</dt><dd>{summary.totalFours} fours, {summary.totalSixes} sixes</dd>
              </dl>
            </section>
          )}
        </main>
      ) : <main><p className="mut">Loading matches…</p></main>}
    </div>
  )
}
