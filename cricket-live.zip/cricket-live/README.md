# Cricket Live

Spring Boot backend + React (Vite) dashboard. Matches are simulated ball by ball every 1.5 s and pushed to the browser over Server-Sent Events.

## Run
Backend (Java 17+, Maven):  cd backend && mvn spring-boot:run     -> http://localhost:8080
Frontend (Node 18+):        cd frontend && npm install && npm run dev  -> http://localhost:5173

## REST API
GET  /api/matches                 all matches with live scores
GET  /api/matches/{id}            one match (scores, squads, commentary)
GET  /api/matches/{id}/players    player batting and bowling stats
GET  /api/matches/{id}/summary    top scorer, best bowler, run rates, result
POST /api/matches                 {"teamA","teamB","venue"} starts a new simulated match
POST /api/matches/{id}/score      {"outcome":"0|1|2|3|4|6|W|Wd"} manual ball update
GET  /api/stream                  SSE stream, event "match" on every ball
