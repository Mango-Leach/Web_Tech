# Electricity Bill Calculator (PHP)

Responsive web application that calculates a domestic electricity bill from the units
consumed, shows a slab-wise breakup, and prints a clean bill.

## Tariff

| Slab            | Rate          |
|-----------------|---------------|
| First 50 units  | Rs. 3.50/unit |
| Next 100 units  | Rs. 4.00/unit |
| Next 100 units  | Rs. 5.20/unit |
| Above 250 units | Rs. 6.50/unit |

The slabs are cumulative — 320 units is billed as
`50x3.50 + 100x4.00 + 100x5.20 + 70x6.50 = Rs. 1550.00`.

## Files

```
index.php              form, validation and the generated bill
includes/bill.php      slab table + calculate_bill() logic
assets/css/style.css   responsive layout + @media print rules
```

## Running it

**With XAMPP** — copy the folder into `C:\xampp\htdocs\` and open
<http://localhost/Electricity_bill_php/>.

**With PHP's built-in server** — from the project folder:

```bash
php -S localhost:8000
```

Then open <http://localhost:8000>.

## Features

- Slab-wise breakup table with unit ranges, rate and per-slab amount
- Server-side validation (name required, units must be a whole number)
- All output escaped with `htmlspecialchars()` — no XSS from the form fields
- Responsive: 2-column form on desktop, single column under 430px
- **Print Bill** button — `@media print` hides the header, form and buttons so
  only the bill itself goes on paper
