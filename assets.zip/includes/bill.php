<?php
/**
 * Electricity bill slab logic.
 *
 *   first 50 units      -> Rs. 3.50 / unit
 *   next 100 units      -> Rs. 4.00 / unit   (units 51 - 150)
 *   next 100 units      -> Rs. 5.20 / unit   (units 151 - 250)
 *   above 250 units     -> Rs. 6.50 / unit
 */

const SLABS = [
    ['label' => 'First 50 units',      'limit' => 50,   'rate' => 3.50],
    ['label' => 'Next 100 units',      'limit' => 100,  'rate' => 4.00],
    ['label' => 'Next 100 units',      'limit' => 100,  'rate' => 5.20],
    ['label' => 'Above 250 units',     'limit' => null, 'rate' => 6.50], // null = no upper limit
];

/**
 * Split the consumed units across the slabs and price each part.
 *
 * @param  int   $units  total units consumed (>= 0)
 * @return array{rows: array<int, array{label:string, rate:float, units:int, amount:float}>, total: float}
 */
function calculate_bill(int $units): array
{
    $remaining = $units;
    $rows      = [];
    $total     = 0.0;
    $from      = 1;

    foreach (SLABS as $slab) {
        if ($remaining <= 0) {
            break;
        }

        // How many of the remaining units fall inside this slab?
        $chargeable = $slab['limit'] === null
            ? $remaining
            : min($remaining, $slab['limit']);

        $amount = $chargeable * $slab['rate'];

        $rows[] = [
            'label'  => $slab['label'],
            'range'  => $from . ' - ' . ($from + $chargeable - 1),
            'rate'   => $slab['rate'],
            'units'  => $chargeable,
            'amount' => $amount,
        ];

        $total     += $amount;
        $remaining -= $chargeable;
        $from      += $chargeable;
    }

    return ['rows' => $rows, 'total' => round($total, 2)];
}

/** Format a number as Indian rupees, e.g. 1234.5 -> "1,234.50" */
function money(float $value): string
{
    return number_format($value, 2);
}
