<?php
require __DIR__ . '/includes/bill.php';

$errors   = [];
$bill     = null;
$name     = '';
$consumer = '';
$month    = '';
$unitsIn  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $consumer = trim($_POST['consumer'] ?? '');
    $month    = trim($_POST['month'] ?? '');
    $unitsIn  = trim($_POST['units'] ?? '');

    if ($name === '') {
        $errors['name'] = 'Please enter the consumer name.';
    }

    if ($unitsIn === '') {
        $errors['units'] = 'Please enter the units consumed.';
    } elseif (!ctype_digit($unitsIn)) {
        $errors['units'] = 'Units must be a whole number (no decimals or letters).';
    } elseif ((int) $unitsIn > 100000) {
        $errors['units'] = 'That looks too large. Enter a value up to 100000.';
    }

    if (!$errors) {
        $bill = calculate_bill((int) $unitsIn);
    }
}

/** Escape for safe HTML output. */
function e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Electricity Bill Calculator</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<header class="site-header no-print">
    <div class="brand">
        <span class="bolt" aria-hidden="true">&#9889;</span>
        <div>
            <h1>State Power Board</h1>
            <p>Online Electricity Bill Calculator</p>
        </div>
    </div>
</header>

<main class="wrap">

    <!-- ---------- input form ---------- -->
    <section class="card form-card no-print">
        <h2>Enter Meter Details</h2>
        <p class="hint">Fill in the reading for the billing period and generate the bill.</p>

        <form method="post" action="index.php" novalidate>
            <div class="grid">
                <div class="field">
                    <label for="name">Consumer Name <span class="req">*</span></label>
                    <input type="text" id="name" name="name" value="<?= e($name) ?>"
                           placeholder="e.g. Archit Boraste" autocomplete="name">
                    <?php if (isset($errors['name'])): ?>
                        <small class="error"><?= e($errors['name']) ?></small>
                    <?php endif; ?>
                </div>

                <div class="field">
                    <label for="consumer">Consumer Number</label>
                    <input type="text" id="consumer" name="consumer" value="<?= e($consumer) ?>"
                           placeholder="e.g. MH-4471-2290">
                </div>

                <div class="field">
                    <label for="month">Billing Month</label>
                    <input type="month" id="month" name="month" value="<?= e($month) ?>">
                </div>

                <div class="field">
                    <label for="units">Units Consumed (kWh) <span class="req">*</span></label>
                    <input type="number" id="units" name="units" min="0" step="1"
                           value="<?= e($unitsIn) ?>" placeholder="e.g. 320">
                    <?php if (isset($errors['units'])): ?>
                        <small class="error"><?= e($errors['units']) ?></small>
                    <?php endif; ?>
                </div>
            </div>

            <div class="actions">
                <button type="submit" class="btn btn-primary">Calculate Bill</button>
                <a href="index.php" class="btn btn-ghost">Reset</a>
            </div>
        </form>

        <!-- tariff reference -->
        <div class="tariff">
            <h3>Tariff Slabs</h3>
            <ul>
                <li><span>First 50 units</span><b>&#8377; 3.50 / unit</b></li>
                <li><span>Next 100 units</span><b>&#8377; 4.00 / unit</b></li>
                <li><span>Next 100 units</span><b>&#8377; 5.20 / unit</b></li>
                <li><span>Above 250 units</span><b>&#8377; 6.50 / unit</b></li>
            </ul>
        </div>
    </section>

    <!-- ---------- generated bill ---------- -->
    <?php if ($bill !== null): ?>
    <section class="card bill" id="bill">
        <div class="bill-head">
            <div>
                <h2>Electricity Bill</h2>
                <p class="muted">State Power Board &mdash; Domestic Connection</p>
            </div>
            <div class="bill-meta">
                <p><b>Bill No:</b> <?= e('EB' . date('ymd') . str_pad((string) random_int(1, 999), 3, '0', STR_PAD_LEFT)) ?></p>
                <p><b>Issued:</b> <?= date('d M Y') ?></p>
            </div>
        </div>

        <dl class="consumer-info">
            <div><dt>Consumer Name</dt><dd><?= e($name) ?></dd></div>
            <div><dt>Consumer No.</dt><dd><?= $consumer !== '' ? e($consumer) : '&mdash;' ?></dd></div>
            <div><dt>Billing Month</dt>
                 <dd><?= $month !== '' ? e(date('F Y', strtotime($month . '-01'))) : '&mdash;' ?></dd></div>
            <div><dt>Units Consumed</dt><dd><?= (int) $unitsIn ?> kWh</dd></div>
        </dl>

        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>Slab</th>
                        <th>Unit Range</th>
                        <th class="num">Units</th>
                        <th class="num">Rate (&#8377;)</th>
                        <th class="num">Amount (&#8377;)</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$bill['rows']): ?>
                    <tr><td colspan="5" class="muted center">No units consumed for this period.</td></tr>
                <?php else: ?>
                    <?php foreach ($bill['rows'] as $row): ?>
                        <tr>
                            <td><?= e($row['label']) ?></td>
                            <td><?= e($row['range']) ?></td>
                            <td class="num"><?= $row['units'] ?></td>
                            <td class="num"><?= money($row['rate']) ?></td>
                            <td class="num"><?= money($row['amount']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="4">Total Amount Payable</th>
                        <th class="num">&#8377; <?= money($bill['total']) ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="total-banner">
            <span>Amount Payable</span>
            <strong>&#8377; <?= money($bill['total']) ?></strong>
        </div>

        <p class="foot-note">
            This is a computer generated bill and does not require a signature.
            Please pay before the due date to avoid a late payment surcharge.
        </p>

        <div class="actions no-print">
            <button type="button" class="btn btn-primary" onclick="window.print()">Print Bill</button>
            <a href="index.php" class="btn btn-ghost">New Bill</a>
        </div>
    </section>
    <?php endif; ?>

</main>

<footer class="site-footer no-print">
    <p>Web Technologies Lab &mdash; Electricity Bill Calculator built with PHP</p>
</footer>

</body>
</html>
